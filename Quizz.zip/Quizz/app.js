
function populate() {
   if (qz.isEnded()){
       showScores();
   }else{
       //show question
       var element = document.getElementById("question");
       element.innerHTML = qz.getQnIndex().text;
       //show choices
       var choices = qz.getQnIndex().choice;
       for (var i = 0; i < choices.length; i++){
           var element = document.getElementById("choice0"+1);
           element.innerHTML = choices[i];
           guess("btn" + i, choices[i]);
       }
       showProgress();
   }
};
function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function () {
        qz.guess(guess);
        //call populate to see whether its endinh
        populate();
    }
}
function showProgress() {
    var currentQnNumber = qz.qnIndex + 1;
    //add a variable to select an element called progres
    var element = document.getElementById("progress");
    element.innerHTML = "" + currentQnNumber + "of the" +qz.qns.length;
}
function showScores() {
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'>Your score: " + qz.score + "</h2>";
    //replacing with two ele
    var element = document.getElementById("qz");
    element.innerHTML = gameOverHtml;

}
//question, array, answer
var qns = [
    new Question("What is PLog in full", ["Java", "C#", "C++", "C"], "C"),
    new Question("which language is used for styling web apps", ["HTML", "JQuery", "C++", "XML"], "CSS"),
    new Question("What is PLog in full", ["Java", "C#", "C++", "C"], "4"),
    new Question("Which language is used for web apps?", ["PHP", "Python", "Javascript", "All"], "All"),
    new Question("MVC is a ----", ["Langu", "Library", "Framework", "All"], "Framework")

]
//Create an object for the Quizz controller
var qz = new Quiz(qns);
populate();