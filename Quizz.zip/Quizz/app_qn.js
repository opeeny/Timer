//three attributes for each question, constructor of class
function Qn(text, choice, answer) {
    this.text = text;
    this.choice = choice;
    this.answer = answer;
}
Qn.prototype.correctAnswer = function(choice){
    //choice parameter that will be containing the values of user correct option
    return choice = this.answer;
}