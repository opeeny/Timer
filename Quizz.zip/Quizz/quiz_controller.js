//contains the scores, number of questions we have
//start with the constructor function
function Quiz(qns) {
    this.score = 0;
    this.qns = qns;
    this.qnIndex = 0;
}
//function to check if our Quizz is over or not
Quiz.prototype.getQnIndex = function () {
    return this.qns (this.qnIndex);
}
Quiz.prototype.isEnded = function () {
    return this.qns.length == this.qnIndex;

}
//function to check if the answer is correct or not
Quiz.prototype.guess = function (answer) {
    if(this.getQnIndex().correctAnswer(answer)){
        this.score++;
    }
    this.qnIndex++;

}